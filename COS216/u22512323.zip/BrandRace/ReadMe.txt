1 vs 5 images at a time:
	I chose to send one image at a time because thise fits the asynchronous style of NodeJS better. For example I think it is necessarily good that while one round is playing the images from the next round can be loaded
Base64:
	I chose to use base64 to encode my images because this option does not rely on external sites to maintain and send the images so it will always be available.
